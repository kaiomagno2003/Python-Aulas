# nome: str = "Edson" # Str
# altura = 1.70 # Float
# peso = 70 # Int
# maiorDeIdade = True # Boolean



# print(f"Olá, seja bem vindo {nome}")


# Pergunte ao usuário seu nome e der uma saudação, use o FString para juntar
# as palavaras.


# nome = input("Digite seu nome: ")

# print(f"Olá, seja bem vindo {nome} ")


# pi = 3.14159

# print(f"o valor é: {round(pi, 2)}")

