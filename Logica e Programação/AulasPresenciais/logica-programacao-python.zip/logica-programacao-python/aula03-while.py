# contador = 0

# while contador <= 5:
#     print(contador)
#     contador = contador + 1


# senha = ""

# while senha != "15613216":
#     senha = int(input("Digite sua senha: "))

print("Entrou no sistema...")


# 1.

# contador = 1

# while contador <= 10:
#     print(contador)
#     contador += 1


# 2. 

# sum_total = 0
# contador = 1

# while contador <= 100:
#     sum_total += contador
#     contador += 1


# print(sum_total)

# 3.

# numero = int(input("Digite um número"))
# contador = 1

# while contador <= 10:
#     total = contador * numero
#     print(f"{contador} X {numero} = {total}" )
#     contador += 1


# 4.

# numero = 10

# while numero > 0:
#     print(numero)
#     numero -= 1

# print("Feliz Ano Novo!")


# opcao = ""

# while opcao != "sair":
#     print("Digite 'sair' para encerrar")
#     opcao = input("Escola uma opção: ")

# 5.


# 6.
# numero = int(input('Digite um numero: '))

# contador = 1

# while contador <= numero:
#     if contador % 2 != 0:
#         print(contador)
    
#     contador += 1


# 7.

# numero = int(input("Digite um número ou digite um número negativo para sair: "))

# soma = 0

# while numero > 0:
#     soma += numero
#     numero = int(input("Digite um número ou digite um número negativo para sair: "))

# print(soma)


# BREAK

# while True:
#     print("Opções dispníveis")
#     print("Opção 1")
#     print("Opção 2")

#     opcao = input("Olá, escolha a opção desejada ou 'sair' para encerrar ")

#     if opcao == "1":
#         print("vc escolheu a opção 1")

#     if opcao == "sair":
#         break
    


# Crie um prgrama que solicite a senha do usuário com o limite de tentativas
# igual a 3. Quando ultrapassar 3, encerre o programa e mostre uma mesangem 
# "limite de tentativas execidadas."