precosCarrinho = (10.50, 29.90, 51, 89, 100)

# Usando o For e While, como posso obter a soma de
# todos os produtos?
