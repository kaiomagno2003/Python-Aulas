# Operadores de comparação

# nome = "Edson"
# sobrenome = "Dantas"
# n1 = 10
# n2 = 20

# nomeEIgual = (nome == sobrenome)

# print(nome == sobrenome) # '==' é igual
# print(nome != sobrenome) # '==' é igual
# print(n1 > n2) # '>' é maior
# print(n1 >= n2) # '>=' é maior ou igual
# print(n1 < n2) # '>' é menor
# print(n1 <= n2) # '>=' é menor ou igual

# Operadores lógicos 
# idade = 20

# eMaiorDeIdade = idade >= 18

# passouExame = True

# podeTirarCNH = eMaiorDeIdade and passouExame

# print(podeTirarCNH)

# Operadores de atribuição

# x = 10

# x = x + 5
# x += 5 # isso equivale a mesma expressão de cima, 
# o mesmo serve para todos os operadores matemáticos


# print(x) 

# Operadores de Atribuição

# nome = "Edson"
# nomes = ("Edson", "Pedro", "Lucas", "Carlos", 10)
# existe = "Edson" in nomes

# print(existe)


# Estrutura condicional

# Crie um programa que pergunte o peso e altura do usuário.
# Como resultado mostre o IMC do usuário

# peso = 70
# altura = 1.70

# imc = peso / (altura * altura)

# if imc <= 18.5:
#     print(f"Seu imc é: {round(imc, 2)} e sua classificação é (Abaixo do Peso)")
# elif imc >= 18.6 and imc <= 24.9:
#     print(f"Seu imc é: {round(imc, 2)} e sua classificação é (Peso Ideal)")
